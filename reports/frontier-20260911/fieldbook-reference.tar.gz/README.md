# Six-Day Public-State Agent Source

This Dataset keeps the long action tables and C++ runtime outside the readable
**Six-Day Public-State Fieldbook** Notebook. The Notebook verifies each file by
SHA-256 before compiling `main.py` and the Linux x86-64 `agent.so`.

The route candidates were derived from complete public Kaggriculture action
histories, including all available public episodes collected for rank 3 Bantam
and rank 8 Zenith Ye, plus candidates from the current public top 200. Runtime
selection uses public state only.

The Dataset contains no credential, private episode, opponent identity lookup,
random-seed lookup, result lookup, or future-shop information.
